# Rock-Paper-Scissor-Game

## Step 1: Run server.py

## Step 2: Open a new terminal and make sure you are in the pwd of the project, then run client.py

## Step 3: Open a new terminal and make sure you are in the pwd of the project, then run client.py again.

## Step 4: Enjoy multiplayer rock paper scissor game.


